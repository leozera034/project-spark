Comandiva — arquivos prontos para subir manualmente no GitHub main.

Pasta 01-transparent-logos
- comandiva-logo-horizontal.png
- comandiva-logo-stacked.png
- comandiva-logo-stacked-alt.png
- comandiva-symbol.png
- comandiva-wordmark.png

Pasta 02-site-assets
- comandiva-app-icon.png
- comandiva-hero-operations.webp
- comandiva-dashboard-preview.webp
- comandiva-mobile-tracking.webp
- comandiva-og-image-1200x630.png
- comandiva-pattern.svg

Observação:
O ZIP foi criado sem recompressão destrutiva dos arquivos de imagem.
